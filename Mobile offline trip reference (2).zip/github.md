repo: MilkieMoon/IrelandTrip
branch: main
path: docs

## Last sync
date: 2026-10-19T00:00:00Z

### Updated in this project
- Built `docs/` as an installable offline PWA of the Ireland 2026 itinerary
- Added service worker (cache-first) so the app runs with no network
- Added web app manifest + pixel shamrock icons for Add to Home Screen
- Repo was empty at time of connection; files uploaded manually by the user

## Screen map
| Project screen | Repo files |
| --- | --- |
| Ireland Itinerary (interactive app) | docs/index.html |
| Offline caching layer | docs/sw.js |
| Install metadata | docs/manifest.webmanifest, docs/icon-192.png, docs/icon-512.png |
