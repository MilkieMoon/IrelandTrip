// Ireland 2026 itinerary data — condensed for offline phone reference.
const maps = (q) => `https://maps.google.com/?q=${encodeURIComponent(q)}`;

export const TRIP = { title: "Ireland 2026", subtitle: "A Samhain Journey", dates: "Nov 3–14, 2026" };

export const QUICKREF = [
  { what: "Outbound Flight", details: "Orlando MCO → Shannon SNN · Nov 2 depart, arrive Nov 3 6am", tel: null, map: null, link: "aerlingus.com" },
  { what: "Return Flight", details: "Shannon SNN → Orlando MCO · Nov 14, depart 1:30pm", tel: null, map: null, link: "aerlingus.com" },
  { what: "Gleann Fia", details: "Lower Coolcorcoran, Kilcummin Rd, Killarney · Nov 2 held + Nov 3–4 · Conor & Bridget · Early check-in ✅", tel: "+353646635035", map: "Gleann Fia Country House Killarney", link: "gleannfia.com" },
  { what: "Kilkenny B&B", details: "Near Kyteler's Inn · Nov 5–13 · 11 min walk to Kyteler's", tel: null, map: "Kyteler's Inn Kilkenny", link: null },
  { what: "Car Hire", details: "Automatic · Pick up Shannon Airport Nov 3 · Drop off Nov 14", tel: null, map: "Shannon Airport", link: null },
  { what: "Sneem Seaweed Baths", details: "Goldens Cove, Drimna Beg, Sneem · Nov 4 · 11am · Booked ✅", tel: "+353857845766", map: "Sneem Seaweed Baths", link: "sneemseaweed.ie" },
  { what: "Kyteler's Inn", details: "St Kieran's Street, Kilkenny · Whiskey tasting + trad music nightly", tel: "+353567721064", map: "Kyteler's Inn Kilkenny", link: "kytelersinn.com" },
  { what: "Valley of Roses", details: "5 Rose Inn St, Kilkenny · Nov 6 · 11am–12pm · Booked ✅", tel: "+353831857588", map: "Valley of Roses Kilkenny", link: "valleyofroses.ie" },
  { what: "Pottery Class", details: "TBC — sourcing local potter · Backup: The Happy Pottery", tel: null, map: null, link: null },
  { what: "Jerpoint Glass", details: "Oldtown, Stoneyford · Free entry · Demos Mon–Thu 10am–4pm, Fri 10am–1pm", tel: "+353567724350", map: "Jerpoint Glass Studio Stoneyford", link: "jerpointglass.com" },
  { what: "Chez Hans Dinner", details: "Moor Lane, Cashel · Nov 7, 5:30pm · Book 2–3 weeks ahead", tel: "+3536261177", map: "Chez Hans, Moor Lane, Cashel, Co. Tipperary, Ireland", link: "chezhans.ie" },
  { what: "Waterford Crystal", details: "The Mall, Waterford · Nov 8 · Tour 10:30am + tea time 12:30pm · Booked ✅", tel: null, map: "House of Waterford Crystal", link: "houseofwaterford.com" },
  { what: "Apothecary Cork", details: "Apothecary at Rockgrove · Email Siobhan Norton directly", tel: null, map: "Coachford Co Cork", link: null },
  { what: "MADE in Kilkenny", details: "Craft trail map — pick up at Kilkenny Design Centre, Castle Yard", tel: null, map: "Kilkenny Design Centre", link: null },
  { what: "Newgrange", details: "Book timed entry min. 1 month ahead for Nov dates", tel: null, map: "Newgrange Brú na Bóinne", link: "heritageireland.ie" }
];

export const CHECKLIST = {
  book: [
    "Sneem Seaweed Baths — booked Nov 4, 11am ✅",
    "Valley of Roses workshop — confirmed ✅",
    "Kyteler's Whiskey Tasting (min. 4 people — contact JD)",
    "Chez Hans dinner — 2–3 weeks ahead",
    "Waterford Crystal tour 10:30am + tea 12:30pm — booked ✅",
    "Smithwick's Experience",
    "Newgrange timed entry — 1 month ahead minimum",
    "Apothecary at Rockgrove — email Siobhan Norton",
    "Pottery class (TBC) or backup Happy Pottery"
  ],
  pack: [
    "Download MADE in Kilkenny trail map before you go",
    "Layers + waterproof jacket (Nov weather)",
    "Swimwear + towel for Sneem seaweed baths",
    "Space in luggage for Aran sweaters, pottery, glass",
    "Bubble wrap / soft clothing for fragile purchases",
    "Phone offline maps downloaded for Kerry, Kilkenny, Cork, Meath",
    "Print or save flight & car hire confirmations",
    "Euro cash for markets and small shops"
  ]
};

export const DAYS = [
{ num:1, weekday:"Monday", date:"Nov 3", title:"Arrival — Shannon to Gleann Fia", subtitle:"Land · Early check-in · Rest · Sweaters · Killarney evening",
  sun:"7:45am–4:55pm", drive:"Shannon → Gleann Fia ~1.5hrs", note:null,
  items:[
    {time:"6:00am", icon:"✈", title:"Land Shannon Airport", tag:null, price:null, map:"Shannon Airport", tel:null, body:"Pre-cleared US customs — walk straight off as a domestic arrival. No queues. Collect bags and head to your car hire desk."},
    {time:"6:30am", icon:"🚗", title:"Drive Shannon → Gleann Fia", tag:null, price:null, map:"Gleann Fia Country House Killarney", tel:null, body:"South toward Kerry on the N18/N21, mostly dual carriageway. About 1.5 hours."},
    {time:"8:00am", icon:"🏡", title:"Early Check-In — Gleann Fia", tag:"Booked ✅", price:null, map:"Gleann Fia Country House Killarney", tel:"+353646635035", body:"Conor and Bridget are expecting you — early check-in arranged and paid. Tea, scones, and the woodland stream through the conservatory window."},
    {time:"8am–12pm", icon:"😴", title:"Rest & Recover", tag:null, price:null, map:null, tel:null, body:"Sleep as long as you need. Best decision you made for this trip."},
    {time:"12:00pm", icon:"🍳", title:"Late Breakfast at Gleann Fia", tag:"Included", price:null, map:null, tel:null, body:"Bridget's homemade bread, fresh eggs, and a full Irish — available late morning for early-arriving guests."},
    {time:"1:30pm", icon:"🧶", title:"Aran Sweater Market — Killarney", tag:"Priority", price:"€100–300pp", map:"Aran Sweater Market Killarney", tel:null, body:"College Street. Two floors of authentic Aran knitwear. Signed Certificate of Authenticity with each piece; staff explain the meaning of every stitch."},
    {time:"3:00pm", icon:"🏘", title:"Explore Killarney Town", tag:null, price:null, map:"Island Organix Killarney", tel:null, body:"Island Organix for herbal/botanical goods, Lir Chocolates for handmade Irish chocolate. Browse at your pace."},
    {time:"4:30pm", icon:"🏰", title:"Optional: Ross Castle", tag:"Optional", price:"Grounds free · Tower ~€5pp", map:"Ross Castle Killarney", tel:null, body:"15th-century tower castle on Lough Leane. Beautiful lakeside walk even without the tower interior."}
  ],
  meals:[{meal:"Dinner", name:"The Laurels", desc:"Beloved local pub — hearty Irish food, live trad music most nights."}],
  budget:[["Car hire (Day 1)","€35–50"],["Aran Sweaters (2)","€150–300"],["Lunch/coffee","€20"],["Dinner — The Laurels","€50"],["Ross Castle (optional)","€10"],["Misc.","€20"]], total:"€285–450",
  tip:"You've arranged early check-in at Gleann Fia — the single smartest thing you did for this trip. Sleep first, explore second." },

{ num:2, weekday:"Tuesday", date:"Nov 4", title:"Kerry Lakes & Sneem Seaweed Baths", subtitle:"Ladies View · Sneem Barrel Soak · Kenmare · Torc Waterfall · Muckross",
  sun:"7:47am–4:52pm", drive:"Killarney → Sneem via Ladies View ~1hr · Sneem → Kenmare 30min · Kenmare → Killarney 45min · leave by 9:30am", note:"Baths are now at 11am, so the day runs out along the lakes to Sneem and back through Kenmare. The full Ring of Kerry loop is dropped to save daylight for Torc Waterfall.",
  items:[
    {time:"8:30am", icon:"🍳", title:"Breakfast at Gleann Fia", tag:"Included", price:null, map:null, tel:null, body:"Homemade bread, fresh eggs, award-winning porridge. One of the great Kerry breakfasts."},
    {time:"9:30am", icon:"🚗", title:"Ladies View & Moll's Gap", tag:null, price:null, map:"Ladies View Kerry", tel:null, body:"Out on the N71 toward Kenmare. One of Ireland's most iconic vistas — the Upper Lake and mountains. A short photo stop, then on to Sneem via Kenmare."},
    {time:"11:00am", icon:"🛁", title:"Sneem Seaweed Baths", tag:"Booked ✅", price:"~€25–40pp", map:"Sneem Seaweed Baths", tel:"+353857845766", body:"Goldens Cove, Drimna Beg, Sneem. Private whiskey-barrel hot tubs filled with warm water and hand-harvested wild Atlantic seaweed, overlooking Kenmare Bay. 1hr sessions, extra time free. Arrive 10–15 minutes early."},
    {time:"12:30pm", icon:"🏘", title:"Sneem Village & Art Studios", tag:null, price:null, map:"Sneem Village", tel:null, body:"Colourful village; browse independent shops and Sneem Art Studio."},
    {time:"1:30pm", icon:"🍲", title:"Lunch in Kenmare", tag:null, price:null, map:"Tom Crean's Kenmare", tel:null, body:"30 minutes back east. Lunch at Tom Crean's, then a short wander round Kenmare's shops."},
    {time:"3:00pm", icon:"🌲", title:"Torc Waterfall & Muckross Abbey", tag:null, price:"Park free · House ~€9pp", map:"Torc Waterfall Killarney", tel:null, body:"On the road back into Killarney. Torc Waterfall through ancient oak woodland, then the ruined Franciscan friary at Muckross with its 600-year-old yew tree. Both free. Sunset is 4:52pm — do Torc first."}
  ],
  meals:[{meal:"Lunch", name:"Tom Crean's Bar, Kenmare", desc:"Named after the legendary Kerry Antarctic explorer."},{meal:"Dinner", name:"Quinlan's Seafood Bar, Killarney", desc:"They own their own fishing boats — the best seafood in Kerry."}],
  budget:[["Car hire","€35–50"],["Muckross House (opt)","€18"],["Sneem Seaweed Baths (2)","€50–80"],["Lunch","€40"],["Dinner","€60"],["Sneem shopping","€20–50"]], total:"€223–298",
  tip:"A warm barrel soak overlooking the Atlantic in November is deeply restorative — don't rush back out." },

{ num:3, weekday:"Wednesday", date:"Nov 5", title:"Kerry → Kilkenny — First Medieval Evening", subtitle:"Checkout · Drive · Medieval Mile · Kyteler's Inn",
  sun:"7:49am–4:50pm", drive:"Killarney → Kilkenny ~2.5–3hrs · leave by 10am", note:"B&B check-in is 4pm — see the indoor sights first and keep the bags in the car. Black Abbey and St Canice's move to Day 11, when you'll have full daylight for the Round Tower.",
  items:[
    {time:"9:00am", icon:"🍳", title:"Final Breakfast at Gleann Fia", tag:"Included", price:null, map:null, tel:null, body:"Last morning with Conor and Bridget. Thank them warmly — this place will stay with you."},
    {time:"10:00am", icon:"🚗", title:"Drive Killarney → Kilkenny", tag:null, price:null, map:"Kilkenny", tel:null, body:"Northeast on N22/N24. Glimpse the Rock of Cashel rising from the plain — save the full visit for Day 5."},
    {time:"1:00pm", icon:"🅿", title:"Arrive Kilkenny — Park & Lunch", tag:null, price:null, map:"Kilkenny", tel:null, body:"Check-in isn't until 4pm, so park centrally and leave the bags in the car. Lunch first, then sightseeing on foot."},
    {time:"2:00pm", icon:"🏛", title:"Medieval Mile Museum", tag:null, price:"Self-guided €7 · Guided €10pp", map:"Medieval Mile Museum Kilkenny", tel:null, body:"13th-century church turned museum of Kilkenny's 800-year history. \"3 Lives, 3 Deaths\" exhibition with forensic life reconstructions. Take the guided tour — allow an hour."},
    {time:"3:15pm", icon:"🏰", title:"Kilkenny Castle & Grounds", tag:null, price:"Grounds free · House ~€8pp", map:"Kilkenny Castle", tel:null, body:"Norman castle at the heart of the city; the Long Gallery restoration is magnificent. Walk the grounds now — sunset is 4:50pm."},
    {time:"4:00pm", icon:"🏡", title:"Check In — Kilkenny B&B", tag:"4pm check-in", price:null, map:"Kyteler's Inn Kilkenny", tel:null, body:"Collect the car, check in, drop the bags and settle. 11-minute walk to Kyteler's from here."},
    {time:"5:00pm", icon:"🛍", title:"National Craft Gallery & Design Centre", tag:null, price:"Free", map:"Kilkenny Design Centre", tel:null, body:"Through the Castle Yard, open into the evening. Ireland's finest collection of contemporary Irish craft — jewellery, ceramics, textiles, glass."}
  ],
  meals:[{meal:"Lunch", name:"The Fig Tree, High Street", desc:"Casual café, excellent full Irish, burgers, all-day brunch."},{meal:"Dinner", name:"Kyteler's Inn", desc:"First night at Dame Alice's pub — stew, chowder, trad music from 8pm."}],
  budget:[["Car hire","€35–50"],["Castle house tour","€16"],["Medieval Mile guided (x2)","€20"],["Lunch","€30"],["Dinner","€60"],["Shopping","€30–100"]], total:"€191–276",
  shopping:["The Book Centre — High Street (since 1971, in-store café)","The Book & Coffee Shop — William Street (second-hand books)","Butterslip Shop — under the flower arch","Yesterdays — Victorian/Art Deco/gifts","Vintage Emporium — antiques + coffee bar","Rudolf Heltzel Jewellers — Parliament Street (since 1968)","Rothe House Shop — Irish-made in a Tudor merchant home","Bridie's — speakeasy-style Irish general store"] },

{ num:4, weekday:"Thursday", date:"Nov 6", title:"Craft Day — Perfume, Glass & Whiskey", subtitle:"Farmers Market · Valley of Roses · Jerpoint Glass · Whiskey Tasting",
  sun:"7:51am–4:47pm", drive:"Jerpoint Glass 20min each way", note:null,
  items:[
    {time:"9:00am", icon:"🛒", title:"Kilkenny Farmers Market — Coal Market", tag:null, price:"Free", map:"Coal Market Kilkenny", tel:null, body:"Thursday market: artisan bread, farmhouse cheese, honey, preserves."},
    {time:"10:00am", icon:"🚶", title:"Browse Kilkenny City Centre", tag:null, price:null, map:"Cakeface Patisserie Kilkenny", tel:null, body:"High Street and Parliament Street. Cakeface Patisserie for coffee and pastry."},
    {time:"11:00am", icon:"🌹", title:"Valley of Roses — Scent Workshop", tag:"Booked ✅", price:"~€25–40pp", map:"Valley of Roses Kilkenny", tel:"+353831857588", body:"5 Rose Inn St. Andriana Tsankova's artisan perfumery, 400+ bespoke vegan fragrances. 1-hour workshop (11am–12pm) to create your own signature scent."},
    {time:"1:30pm", icon:"🔥", title:"Jerpoint Glass Studio — Stoneyford", tag:null, price:"Glass free · Abbey ~€5pp", map:"Jerpoint Glass Studio", tel:"+353567724350", body:"Watch master glassblowers — demos Mon–Thu 10am–4pm, Fri 10am–1pm. Made the goblets used in Harry Potter. Jerpoint Abbey ruins (13th c.) directly across the road."},
    {time:"4:00pm", icon:"🛍", title:"National Craft Gallery & Design Centre", tag:null, price:"Free", map:"Kilkenny Design Centre", tel:null, body:"Return to Kilkenny; browse Castle Yard galleries."},
    {time:"5:00pm", icon:"🏺", title:"Pottery Class — TBC", tag:"TBC", price:"~€40–60pp", map:"The Happy Pottery", tel:null, body:"Sourcing a local Kilkenny potter. The Happy Pottery is the backup option."},
    {time:"6:30pm", icon:"🥃", title:"Whiskey Tasting — Kyteler's Inn", tag:"Book ahead", price:"€30–100pp", map:"Kyteler's Inn Kilkenny", tel:"+353567721064", body:"JD Flynn guides you through Irish whiskey history with Dame Alice's story woven in. 4 (or 6 premium) whiskeys. Minimum 4 people — contact JD to arrange for two."}
  ],
  meals:[{meal:"Lunch", name:"Foodworks, Parliament Street", desc:"Excellent seasonal Irish cuisine, local produce."},{meal:"Dinner", name:"Ristorante Rinuccini, The Parade", desc:"Family-owned Italian institution near the castle for 30 years."}],
  budget:[["Car hire","€35–50"],["Valley of Roses (x2)","€50–80"],["Jerpoint Abbey (x2)","€10"],["Pottery TBC (x2)","€80–120"],["Whiskey tasting (x2)","€60–200"],["Lunch","€35"],["Dinner","€70"],["Market","€20–40"]], total:"€380–705",
  tip:"Today you created a personal perfume, watched master glassblowers, and tasted whiskey in a 700-year-old witch's pub." },

{ num:5, weekday:"Friday", date:"Nov 7", title:"Rock of Cashel & Tipperary", subtitle:"Rock of Cashel · Cahir Castle · Kilkenomics Evening",
  sun:"7:52am–4:47pm", drive:"Kilkenny↔Cashel 45min · Cashel↔Cahir 20min", note:"Kilkenomics Festival runs Nov 7–9 — pubs fill with economists, comedians, and curious minds.",
  items:[
    {time:"9:30am", icon:"🏰", title:"Rock of Cashel", tag:null, price:"~€8pp", map:"Rock of Cashel", tel:null, body:"Medieval buildings on a limestone outcrop — round tower, Romanesque Cormac's Chapel, Gothic cathedral. Brian Boru crowned here 978 AD. Open 9am–4:45pm; allow 2 hours."},
    {time:"11:30am", icon:"🏰", title:"Optional: Cahir Castle", tag:"Optional", price:"~€5pp", map:"Cahir Castle", tel:null, body:"One of Ireland's largest, best-preserved medieval castles, 20 min from Cashel. Used in several major films."},
    {time:"2:30pm", icon:"🧀", title:"Cashel Local Shops", tag:null, price:null, map:"Cashel town", tel:null, body:"Cashel Blue farmhouse cheese at a local deli; browse small independent shops."},
    {time:"5:30pm", icon:"🍽", title:"Dinner — Chez Hans", tag:"Book ahead", price:"€100–130 for two", map:"Chez Hans, Moor Lane, Cashel, Co. Tipperary, Ireland", tel:"+3536261177", body:"Moor Lane, Cashel, Co. Tipperary. Legendary restaurant in a restored 1861 church beneath the Rock of Cashel, run by the Matthiae family since 1968. Book 2–3 weeks ahead."},
    {time:"9:00pm", icon:"🎭", title:"Optional: Kilkenomics Evening", tag:"Optional", price:"€15–40pp", map:"Kilkenny", tel:null, body:"Check the programme — ticketed events and free pub shows. Saturday night is the biggest evening."}
  ],
  meals:[{meal:"Lunch", name:"Mikey Ryan's Bar & Kitchen, Cashel", desc:"Locally sourced, genuine Irish cooking."},{meal:"Dinner", name:"Chez Hans, Moor Lane, Cashel", desc:"Legendary restaurant in a restored church, since 1968. 5:30pm booking. BOOK 2–3 WEEKS AHEAD."}],
  budget:[["Car hire","€35–50"],["Rock of Cashel (x2)","€16"],["Cahir Castle (opt, x2)","€10"],["Lunch","€40"],["Dinner — Chez Hans","€100–130"],["Kilkenomics (opt)","€30–80"],["Shopping/cheese","€15–40"]], total:"€246–366" },

{ num:6, weekday:"Saturday", date:"Nov 8", title:"Waterford — Crystal & Vikings", subtitle:"Waterford Crystal Factory · Viking Triangle · Medieval Museum",
  sun:"7:54am–4:44pm", drive:"Kilkenny↔Waterford 34min each way", note:null,
  items:[
    {time:"10:30am", icon:"💎", title:"House of Waterford Crystal — Factory Tour", tag:"Booked ✅", price:"~€15pp", map:"House of Waterford Crystal, The Mall, Waterford, Ireland", tel:null, body:"The Mall, Waterford. Watch craftspeople blow molten crystal at 1300°C. World's largest display of Waterford Crystal. Fully guided, about 50 minutes. Arrive 10–15 minutes early."},
    {time:"12:30pm", icon:"🫖", title:"Tea Time — House of Waterford Crystal", tag:"Booked ✅", price:null, map:"House of Waterford Crystal, The Mall, Waterford, Ireland", tel:null, body:"Afternoon tea reservation, booked with the tour. A slow, sit-down break before heading into the old city."},
    {time:"1:45pm", icon:"⚔", title:"Waterford Viking Triangle", tag:null, price:"~€5pp each", map:"Reginald's Tower Waterford", tel:null, body:"Reginald's Tower (1003 AD, Ireland's oldest civic building), Medieval Museum's Treasures of Waterford, and the Bishop's Palace — 1,000+ years in a walkable triangle, steps from the crystal factory. Pick one or two museums; sunset is 4:44pm."},
    {time:"3:45pm", icon:"🛍", title:"Waterford City Independent Shops", tag:null, price:null, map:"Waterford City", tel:null, body:"Look for Waterford Crystal seconds at smaller shops. The Book Centre Waterford is in the old Art Deco Savoy Cinema."},
    {time:"7:00pm", icon:"🎭", title:"Optional: Kilkenomics Saturday Night", tag:"Optional", price:"Various", map:"Kilkenny", tel:null, body:"Biggest night of the festival — check kilkenomics.com."}
  ],
  meals:[{meal:"Lunch", name:"Tea Time, House of Waterford Crystal", desc:"12:30pm reservation, booked with the tour."},{meal:"Dinner", name:"Zuni, Patrick Street, Kilkenny", desc:"Contemporary Irish cuisine, seasonal ingredients, great early bird."}],
  budget:[["Car hire","€35–50"],["Crystal tour + tea time (x2)","Booked"],["Viking Triangle (x2)","€30"],["Dinner","€60"],["Kilkenomics (opt)","€30–80"],["Shopping","€20–150"]], total:"€175–370 + prepaid tour" },

{ num:7, weekday:"Sunday", date:"Nov 9", title:"Slow Kilkenny Day — Markets, Art & Smithwick's", subtitle:"Farmers Market · Smithwick's Experience · Butler Gallery · Theatre",
  sun:"7:56am–4:41pm", drive:"No driving — everything walkable", note:null,
  items:[
    {time:"9:00am", icon:"🛒", title:"Kilkenny Farmers Market — Coal Market", tag:null, price:"Free", map:"Coal Market Kilkenny", tel:null, body:"Sunday market: artisan bread, cheese, smoked fish, honey."},
    {time:"10:30am", icon:"🍺", title:"Smithwick's Experience", tag:"Book ahead", price:"~€16pp", map:"Smithwick's Experience Kilkenny", tel:null, body:"Guided tour of the brewery site — operating since 1710 on a 13th-century friary site. Includes tastings."},
    {time:"12:00pm", icon:"🎨", title:"Butler Gallery — Castle Basement", tag:null, price:"Free", map:"Butler Gallery Kilkenny", tel:null, body:"Contemporary art in the medieval castle basement — rotating Irish and international exhibitions."},
    {time:"5:00pm", icon:"🎭", title:"Optional: Watergate Theatre", tag:"Optional", price:"€15–30pp", map:"Watergate Theatre Kilkenny", tel:null, body:"Check the November programme — theatre, music, or comedy."},
    {time:"7:30pm", icon:"🧙", title:"Optional: Irish Coffee Experience — Kyteler's", tag:"Book ahead", price:"~€15pp", map:"Kyteler's Inn Kilkenny", tel:"+353567721064", body:"Learn to make the perfect Irish Coffee with Dame Alice's story woven in."}
  ],
  meals:[{meal:"Lunch", name:"Campagne Restaurant, Gas House Lane", desc:"Michelin-starred since 2009 — book the early bird."},{meal:"Dinner", name:"Matt The Millers, John Street", desc:"Beloved pub — Kilkenny Red Ale Beef Pie, live music most nights."}],
  budget:[["Smithwick's (x2)","€32"],["Lunch — Campagne","€70"],["Dinner","€55"],["Theatre (opt, x2)","€30–60"],["Irish Coffee exp (opt)","€30"],["Shopping","€30–200"]], total:"€247–447",
  shopping:["Bargain Books — The Butterslip (from €1)","Bridge Antiques — top-rated in Kilkenny","Yvonne Ross Jewellery Studio — award-winning goldsmith","Kilkenny Design Centre Shop — Castle Yard","MADE in Kilkenny Craft Trail — download the map"] },

{ num:8, weekday:"Monday", date:"Nov 10", title:"Cork City & Blarney Castle", subtitle:"Blarney Grounds · Rock Close · Woollen Mills · English Market · Crawford",
  sun:"7:58am–4:38pm", drive:"Kilkenny→Blarney ~1h55 · Cork→Kilkenny ~1h49 · leave by 8am", note:null,
  items:[
    {time:"8:00am", icon:"🚗", title:"Early Start — Drive to Blarney", tag:null, price:null, map:"Blarney Castle", tel:null, body:"Leave by 8am on the M8."},
    {time:"10:00am", icon:"🏰", title:"Blarney Castle & Rock Close", tag:null, price:"Castle+grounds ~€18pp · Mills free", map:"Blarney Castle Rock Close", tel:null, body:"The REAL gem is Rock Close — an ancient druidic garden with a Witch's Kitchen, wishing steps, Fairy Glade, and 300-year-old yew walk. Blarney Woollen Mills next door for wool and tweed."},
    {time:"12:00pm", icon:"🛒", title:"Cork English Market", tag:null, price:"Market free · Lunch ~€15pp", map:"English Market Cork", tel:null, body:"One of Europe's finest covered food markets, trading since 1788. Lunch upstairs at Farmgate Café overlooking the market floor."},
    {time:"2:00pm", icon:"🎨", title:"Crawford Art Gallery", tag:null, price:"Free", map:"Crawford Art Gallery Cork", tel:null, body:"Cork's national gallery — 18th century to today. The sculpture hall is extraordinary."},
    {time:"3:00pm", icon:"🚶", title:"Cork City Walk & Independent Shops", tag:null, price:null, map:"Cork City", tel:null, body:"River Lee, St Fin Barre's Cathedral interior, Patrick Street, McCurtain Street shops."},
    {time:"3:45pm", icon:"🔔", title:"Optional: Shandon Bells", tag:"Optional", price:"~€6pp", map:"Shandon Bells Cork", tel:null, body:"Climb the tower and ring the famous bells at St Anne's Church."}
  ],
  meals:[{meal:"Lunch", name:"Farmgate Café, English Market", desc:"Fresh local produce cooked simply — the most Cork lunch possible."},{meal:"Dinner", name:"Statham's by Pembroke, Kilkenny", desc:"Best Contemporary Irish Cuisine, Leinster 2024. Farm-to-fork."}],
  budget:[["Car hire","€35–50"],["Blarney Castle (x2)","€36"],["English Market shopping","€20–60"],["Shandon Bells (opt, x2)","€12"],["Lunch","€40"],["Dinner","€80"],["Blarney Mills/Cork shopping","€30–150"]], total:"€253–428",
  tip:"Rock Close at Blarney is genuinely witchy — the Witch's Kitchen, wishing steps, druidic stones, and yew walk. Allow at least 1.5 hours." },

{ num:9, weekday:"Tuesday", date:"Nov 11", title:"West Cork — Apothecary, Nature Trails & Artisan Trail", subtitle:"Apothecary at Rockgrove · Lough Hyne · Skibbereen · Bantry",
  sun:"7:59am–4:36pm", drive:"Longest driving day — ~5–6hrs total · LEAVE BY 7:30AM", note:"Daylight lasts until ~4:30pm — front-load outdoor activities early. Worth every mile.",
  items:[
    {time:"7:30am", icon:"🚗", title:"Early Start — Drive to West Cork", tag:null, price:null, map:"Coachford Co Cork", tel:null, body:"Head south and west toward County Cork."},
    {time:"9:45am", icon:"🌿", title:"Apothecary at Rockgrove — Coachford", tag:"Book ahead", price:"Contact for pricing", map:"Coachford Co Cork", tel:null, body:"Herbalist Siobhan Norton's 2-acre working herbal practice, combining Chinese and Western traditions with native Irish plants. A rare, meaningful experience — contact Siobhan in advance."},
    {time:"11:30am", icon:"🥾", title:"Lough Hyne Hill Walk — Skibbereen", tag:null, price:"Free", map:"Lough Hyne Skibbereen", tel:null, body:"Ireland's first Marine Nature Reserve. 6km moderate walk to Knockomagh Hill (197m); 9 points of interest from the Heritage Centre. Allow 2–2.5 hours."},
    {time:"2:00pm", icon:"🎨", title:"Skibbereen — Arts & Craft Galleries", tag:null, price:null, map:"Skibbereen", tel:null, body:"West Cork's creative hub — arts centre, galleries, craft studios with no tourist polish."},
    {time:"3:00pm", icon:"🌊", title:"Optional: Bantry Bay — Lady Bantry's Lookout", tag:"Optional", price:"Free", map:"Glengarriff Nature Reserve", tel:null, body:"30 min from Skibbereen. 6km loop through ancient oak woodland to a lookout over Bantry Bay. Red deer possible."}
  ],
  meals:[{meal:"Lunch", name:"Manning's Emporium, Ballylickey", desc:"Extraordinary West Cork food shop and café."},{meal:"Dinner", name:"Petronella, The Butterslip, Kilkenny", desc:"Named after Petronilla de Meath. Stone walls, extensive vegan menu."}],
  budget:[["Car hire","€35–50"],["Apothecary","TBC"],["Lough Hyne walk","Free"],["Lunch","€30"],["Dinner","€60"],["Shopping","€20–100"]], total:"€145–240 + apothecary" },

{ num:10, weekday:"Wednesday", date:"Nov 12", title:"Hill of Tara & Boyne Valley", subtitle:"Hill of Tara · Newgrange · Hill of Ward (Tlachtga)",
  sun:"8:01am–4:33pm", drive:"Kilkenny→Tara ~2hrs · Tara→Newgrange 30min · leave by 7:45am", note:"Your sacred Samhain day. The Boyne Valley in early November is quiet and atmospheric — drive this route as pilgrimage.",
  items:[
    {time:"7:45am", icon:"🚗", title:"Early Drive North — County Meath", tag:null, price:null, map:"Hill of Tara", tel:null, body:"M9 and M7 toward the Boyne Valley. About 2 hours."},
    {time:"10:00am", icon:"🗿", title:"Hill of Tara — Seat of the High Kings", tag:null, price:"Free / small parking fee", map:"Hill of Tara", tel:null, body:"The Lia Fáil (Stone of Destiny) — where every High King was crowned. On Samhain, the veil between worlds was believed thinnest here. Allow 1.5 hours; a guided tour is recommended."},
    {time:"11:30am", icon:"🏛", title:"Newgrange — Brú na Bóinne", tag:"Book ahead", price:"~€14pp", map:"Newgrange", tel:null, body:"Older than Stonehenge and the Pyramids, built ~3200 BC, aligned to the winter solstice sunrise. Book timed entry at least 1 month ahead. Knowth closed Nov–Feb; Newgrange stays open."},
    {time:"1:00pm", icon:"🔥", title:"Hill of Ward (Tlachtga) — Athboy", tag:null, price:"Free", map:"Hill of Ward Athboy", tel:null, body:"The original site of the Samhain fire ceremony, where the great bonfire was lit each Celtic new year. Quiet and ancient in November — just the hill and the wind."}
  ],
  meals:[{meal:"Lunch", name:"Newgrange Farm Coffee Shop, Slane", desc:"A working farm near the Boyne Valley sites."},{meal:"Dinner", name:"La Rivista, Parliament Street, Kilkenny", desc:"Excellent value Italian, cosy and warm."}],
  budget:[["Car hire","€35–50"],["Hill of Tara","Free + €2–5"],["Newgrange (x2)","€28"],["Lunch","€30"],["Dinner","€55"],["Fuel/misc","€20"]], total:"€170–188" },

{ num:11, weekday:"Thursday", date:"Nov 13", title:"Final Kilkenny Day — Markets, Pack & Farewell", subtitle:"Last market · Final craft shopping · Pack · Kyteler's farewell",
  sun:"8:03am–4:30pm", drive:"No driving — last full day in Kilkenny", note:null,
  items:[
    {time:"9:00am", icon:"🛒", title:"Thursday Farmers Market — Last Chance", tag:null, price:null, map:"Coal Market Kilkenny", tel:null, body:"Final purchases — local cheese, honey, soda bread, artisan goods."},
    {time:"10:30am", icon:"🗺", title:"MADE in Kilkenny Craft Trail — Final Walk", tag:null, price:"Free", map:"Kilkenny Castle Yard", tel:null, body:"Walk the city's craft studios one final time — silversmiths, potters, weavers, printmakers, many open Thu–Sat."},
    {time:"2:00pm", icon:"🏰", title:"Last Medieval Mile Walk", tag:null, price:null, map:"St Canice's Cathedral Kilkenny", tel:null, body:"Black Abbey — 13th-century Dominican friary with medieval stained glass — then climb St Canice's Round Tower for the view over Kilkenny in the November afternoon light."},
    {time:"4:00pm", icon:"📦", title:"Pack", tag:null, price:null, map:null, tel:null, body:"Wrap fragile items (pottery, glass) in base layers and soft clothing. Keep whiskey bottles central and upright."}
  ],
  meals:[{meal:"Lunch", name:"Marble City Bar, High Street", desc:"One of Kilkenny's oldest pubs — relaxed, central."},{meal:"Dinner", name:"Kyteler's Inn — FAREWELL", desc:"Last night in Dame Alice's pub. Order the whiskeys you haven't tried. Stay for the full trad session."}],
  budget:[["Farmers Market","€20–60"],["Craft trail/shopping","€30–200"],["Books/oddities","€20–80"],["Lunch","€35"],["Dinner — Kyteler's farewell","€70"],["Black Abbey + Round Tower (x2)","€10"]], total:"€185–455",
  shopping:["The Book Centre — last chance for Samhain/witch-craft books","Bargain Books — final €1–5 sweep","Kilkenny Design Centre — final Irish-made gifts","Valley of Roses — more fragrance products"] },

{ num:12, weekday:"Friday", date:"Nov 14", title:"Departure — Cliffs of Moher & Fly Home", subtitle:"Kilkenny → Burren → Cliffs of Moher → Shannon → Orlando",
  sun:"8:04am–4:28pm", drive:"Kilkenny→Cliffs ~2.5–3hrs · Cliffs→Shannon 55min · LEAVE BY 7AM", note:"Ireland saves the best for last — the Cliffs of Moher on a November morning, then home.",
  items:[
    {time:"7:00am", icon:"🚗", title:"Leave Kilkenny — Final Drive", tag:null, price:null, map:"The Burren", tel:null, body:"Head northwest toward County Clare. A quiet, beautiful final Irish morning."},
    {time:"9:00am", icon:"🪨", title:"The Burren — Poulnabrone Dolmen", tag:null, price:"Free", map:"Poulnabrone Dolmen", tel:null, body:"A 5,000-year-old portal tomb standing alone in lunar limestone karst. No booking needed; allow 20 minutes."},
    {time:"9:30am", icon:"🎵", title:"Optional: Doolin — Gus O'Connor's", tag:"Optional", price:null, map:"Gus O'Connor's Doolin", tel:null, body:"A last bowl of chowder in the most famous trad music village in Ireland. 10 minutes before the Cliffs."},
    {time:"10:00am", icon:"🌊", title:"FAREWELL — Cliffs of Moher", tag:null, price:"~€8pp", map:"Cliffs of Moher", tel:null, body:"214 metres of cliff rising from the Atlantic. Walk the coastal path both directions as far as feels right."},
    {time:"11:30am", icon:"🚗", title:"Drive to Shannon Airport", tag:null, price:null, map:"Shannon Airport", tel:null, body:"55 minutes. Return your hire car — drop off is easy."},
    {time:"12:15pm", icon:"🛫", title:"Shannon Airport — Check In & US Pre-clearance", tag:null, price:null, map:"Shannon Airport", tel:null, body:"US customs completed here. Land in Orlando as a domestic arrival, no queues. Kilkenny Design Centre shop in the terminal for last-minute gifts."},
    {time:"1:30pm", icon:"✈", title:"Depart Shannon → Orlando MCO", tag:null, price:null, map:null, tel:null, body:"You leave with Aran sweaters, your own pottery piece, a perfume you created, a bottle of Irish whiskey, and twelve days of ancient history and Irish hospitality."}
  ],
  meals:[{meal:"Breakfast", name:"Shannon Airport café", desc:"One last Irish coffee before boarding."}],
  budget:[["Car hire drop-off","€35–50"],["Cliffs of Moher (x2)","€16"],["Doolin chowder (opt)","€20"],["Airport coffee","€20"],["Kilkenny Design shop","€20–80"]], total:"€111–186" }
];
